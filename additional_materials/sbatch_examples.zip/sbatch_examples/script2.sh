#!/bin/bash
#SBATCH --time=10
#SBATCH --ntasks-per-node=2 # Количество MPI процессов на узел
#SBATCH --partition=gpu
#SBATCH --nodes=2			# число узлов кластера
#SBATCH --ntasks=4          # Количество MPI процессов
export OMP_NUM_THREADS=16	# число потоков openmp 
export KMP_AFFINITY="granularity=fine,compact,1,0" # привязка omp-потоков к ядрам
mpiexec.hydra ./test.a      # вызов mpi-приложения


