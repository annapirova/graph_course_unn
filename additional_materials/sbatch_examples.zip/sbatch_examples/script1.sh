#!/bin/bash
#SBATCH --time=120       # время на задачу
#SBATCH --partition=gpu  # раздел кластера, мы используем gpu
#SBATCH --cpus-per-task=4 # число процессов на узел
#SBATCH --chdir=climate-networks/src/ # это переход к нужной папке

# далее вызовы скриптов, которые выполняют счет, они внутри себя могут вызывать srun
python -m main --add_input_data

# или
srun <приложение>

# https://slurm.schedmd.com/sbatch.html - это документация
# https://hpc.hse.ru/instructions/run-advanced - здесь много примеров
