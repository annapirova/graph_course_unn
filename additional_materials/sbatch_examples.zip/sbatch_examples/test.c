// сборка: mpicc -fopenmp -O2 test.c -o test.a

#include <stdio.h>
#include <mpi.h>
#include <omp.h>

int main(int argc, char **argv)
{
   int node;
   int nth;
   // Get the name of the processor
   char processor_name[MPI_MAX_PROCESSOR_NAME];
   int name_len;
   
   MPI_Init(&argc,&argv);
   MPI_Comm_rank(MPI_COMM_WORLD, &node);
   nth = omp_get_max_threads();
   MPI_Get_processor_name(processor_name, &name_len);
     
   printf("Hello World from processor %s: rank %d, %d threads\n", 
	processor_name, node, nth);
         
   MPI_Finalize();
   return 0;
}