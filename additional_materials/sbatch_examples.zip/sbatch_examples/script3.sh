#!/bin/bash
#SBATCH --time=10 
#SBATCH --partition=gpu
#SBATCH --nodes=2			# два узла кластера
export OMP_NUM_THREADS=16


# внешний цикл i*j = общее число процессов
# внутренний цикл  = число процессов на узел
for i in {2,4}
do
	echo $i
	for j in {1,2}
	do
		echo $j
		mpiexec.hydra -n $((i*j)) -ppn $j ./test.a
	done
done

# это цикл только по общему числу MPI процессов
# for i in {2,4}
# do
	# echo $i
	# mpiexec.hydra -n $i ./test.a
# done
